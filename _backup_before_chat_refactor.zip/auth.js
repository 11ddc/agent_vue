import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import api from '@/api/mock.js'

export const useAuthStore = defineStore('auth', () => {
  // ===== 状态 =====
  const user = ref(loadUserFromStorage())
  const token = ref(localStorage.getItem('auth_token') || '')
  const showLoginModal = ref(false)
  const showRegisterModal = ref(false)

  // ===== 计算属性 =====
  const isLoggedIn = computed(() => !!token.value && !!user.value)
  const username = computed(() => user.value?.username || '')
  const avatar = computed(() => user.value?.avatar || '')

  // ===== 方法 =====
  function loadUserFromStorage() {
    try {
      const stored = localStorage.getItem('auth_user')
      return stored ? JSON.parse(stored) : null
    } catch {
      return null
    }
  }

  function saveToStorage() {
    if (token.value) localStorage.setItem('auth_token', token.value)
    else localStorage.removeItem('auth_token')

    if (user.value) localStorage.setItem('auth_user', JSON.stringify(user.value))
    else localStorage.removeItem('auth_user')
  }

  async function login(username, password) {
    try {
      const res = await api.post('/auth/login', { username, password })
      if (res.data.code === 200) {
        token.value = res.data.data.token
        user.value = res.data.data.user
        saveToStorage()
        return { success: true, message: res.data.message }
      }
      return { success: false, message: res.data.message }
    } catch (err) {
      return { success: false, message: '网络错误，请稍后重试' }
    }
  }

  async function register(username, email, password) {
    try {
      const res = await api.post('/auth/register', { username, email, password })
      if (res.data.code === 200) {
        token.value = res.data.data.token
        user.value = res.data.data.user
        saveToStorage()
        return { success: true, message: res.data.message }
      }
      return { success: false, message: res.data.message }
    } catch (err) {
      return { success: false, message: '网络错误，请稍后重试' }
    }
  }

  function logout() {
    token.value = ''
    user.value = null
    localStorage.removeItem('auth_token')
    localStorage.removeItem('auth_user')
  }

  function openLogin() {
    showRegisterModal.value = false
    showLoginModal.value = true
  }

  function openRegister() {
    showLoginModal.value = false
    showRegisterModal.value = true
  }

  function closeModals() {
    showLoginModal.value = false
    showRegisterModal.value = false
  }

  function switchToRegister() {
    showLoginModal.value = false
    showRegisterModal.value = true
  }

  function switchToLogin() {
    showRegisterModal.value = false
    showLoginModal.value = true
  }

  return {
    user,
    token,
    showLoginModal,
    showRegisterModal,
    isLoggedIn,
    username,
    avatar,
    login,
    register,
    logout,
    openLogin,
    openRegister,
    closeModals,
    switchToRegister,
    switchToLogin,
  }
})
