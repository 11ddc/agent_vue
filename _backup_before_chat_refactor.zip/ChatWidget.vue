<script setup>
import { watch, nextTick } from 'vue'
import { useChatStore } from '@/stores/chat.js'

const chat = useChatStore()

function handleKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    chat.sendMessage()
  }
}

// 打开时自动滚动到底部
watch(
  () => chat.isOpen,
  async (val) => {
    if (val) {
      await nextTick()
      chat.scrollToBottom()
    }
  },
)
</script>

<template>
  <!-- 聊天弹窗 -->
  <Teleport to="body">
    <Transition name="chat-slide">
      <div v-if="chat.isOpen" class="chat-widget">
        <!-- 头部 -->
        <div class="chat-header">
          <div class="chat-header-left">
            <div class="chat-avatar">🤖</div>
            <div class="chat-header-info">
              <span class="chat-agent-name">客服小优</span>
              <span class="chat-agent-status">在线</span>
            </div>
          </div>
          <button class="chat-close" @click="chat.close()">&times;</button>
        </div>

        <!-- 消息区 -->
        <div id="chat-messages" class="chat-messages">
          <div
            v-for="msg in chat.messages"
            :key="msg.id"
            class="chat-message"
            :class="msg.sender === 'user' ? 'message-user' : 'message-agent'"
          >
            <div class="message-bubble" v-text="msg.content"></div>
            <div class="message-time">
              {{ new Date(msg.timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }) }}
            </div>
          </div>

          <!-- 正在输入提示 -->
          <div v-if="chat.isSending" class="message-agent chat-message">
            <div class="message-bubble typing-bubble">
              <span class="typing-dot"></span>
              <span class="typing-dot"></span>
              <span class="typing-dot"></span>
            </div>
          </div>
        </div>

        <!-- 快捷问题 -->
        <div class="chat-quick">
          <span class="quick-label">常见问题：</span>
          <button
            v-for="q in chat.quickQuestions"
            :key="q"
            class="quick-btn"
            @click="chat.sendQuickQuestion(q)"
          >
            {{ q }}
          </button>
        </div>

        <!-- 输入区 -->
        <div class="chat-input-area">
          <input
            v-model="chat.inputText"
            type="text"
            class="chat-input"
            placeholder="输入您的问题..."
            @keydown="handleKeydown"
          />
          <button
            class="chat-send-btn"
            :disabled="!chat.inputText.trim() || chat.isSending"
            @click="chat.sendMessage()"
          >
            发送
          </button>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.chat-widget {
  position: fixed;
  right: 24px;
  bottom: 24px;
  width: 380px;
  height: 520px;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.18);
  display: flex;
  flex-direction: column;
  z-index: 999;
  overflow: hidden;
}

/* 过渡动画 */
.chat-slide-enter-active {
  animation: chatSlideIn 0.3s ease;
}
.chat-slide-leave-active {
  animation: chatSlideOut 0.25s ease;
}

@keyframes chatSlideIn {
  from {
    transform: translateY(40px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes chatSlideOut {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(40px);
    opacity: 0;
  }
}

/* 头部 */
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  background: linear-gradient(135deg, #ff6b35, #f7931e);
  color: #fff;
}

.chat-header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.chat-avatar {
  width: 40px;
  height: 40px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
}

.chat-header-info {
  display: flex;
  flex-direction: column;
}

.chat-agent-name {
  font-size: 16px;
  font-weight: 600;
}

.chat-agent-status {
  font-size: 12px;
  opacity: 0.85;
}

.chat-close {
  border: none;
  background: none;
  color: #fff;
  font-size: 28px;
  cursor: pointer;
  opacity: 0.8;
  line-height: 1;
}

.chat-close:hover {
  opacity: 1;
}

/* 消息区 */
.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background: #f7f8fa;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.chat-message {
  display: flex;
  flex-direction: column;
  max-width: 80%;
}

.message-user {
  align-self: flex-end;
  align-items: flex-end;
}

.message-agent {
  align-self: flex-start;
  align-items: flex-start;
}

.message-bubble {
  padding: 10px 14px;
  border-radius: 14px;
  font-size: 14px;
  line-height: 1.6;
  word-break: break-word;
}

.message-user .message-bubble {
  background: #ff6b35;
  color: #fff;
  border-bottom-right-radius: 4px;
}

.message-agent .message-bubble {
  background: #fff;
  color: #333;
  border-bottom-left-radius: 4px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.message-time {
  font-size: 11px;
  color: #bbb;
  margin-top: 4px;
  padding: 0 4px;
}

/* 正在输入 */
.typing-bubble {
  display: flex;
  gap: 4px;
  padding: 12px 16px;
}

.typing-dot {
  width: 7px;
  height: 7px;
  background: #ccc;
  border-radius: 50%;
  animation: typingBounce 1.4s infinite ease-in-out both;
}

.typing-dot:nth-child(1) { animation-delay: -0.32s; }
.typing-dot:nth-child(2) { animation-delay: -0.16s; }
.typing-dot:nth-child(3) { animation-delay: 0s; }

@keyframes typingBounce {
  0%, 80%, 100% { transform: scale(0.6); }
  40% { transform: scale(1); }
}

/* 快捷问题 */
.chat-quick {
  padding: 10px 16px;
  background: #fff;
  border-top: 1px solid #f0f0f0;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
}

.quick-label {
  font-size: 12px;
  color: #999;
  margin-right: 4px;
}

.quick-btn {
  padding: 4px 10px;
  border: 1px solid #e8e8e8;
  border-radius: 14px;
  background: #fff;
  font-size: 12px;
  color: #666;
  cursor: pointer;
  transition: all 0.2s;
}

.quick-btn:hover {
  border-color: #ff6b35;
  color: #ff6b35;
  background: #fff5f0;
}

/* 输入区 */
.chat-input-area {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  border-top: 1px solid #f0f0f0;
  gap: 10px;
  background: #fff;
}

.chat-input {
  flex: 1;
  padding: 10px 14px;
  border: 1px solid #e8e8e8;
  border-radius: 20px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s;
}

.chat-input:focus {
  border-color: #ff6b35;
}

.chat-send-btn {
  padding: 10px 18px;
  border: none;
  border-radius: 20px;
  background: #ff6b35;
  color: #fff;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.2s;
  white-space: nowrap;
}

.chat-send-btn:hover:not(:disabled) {
  background: #e55a2b;
}

.chat-send-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
