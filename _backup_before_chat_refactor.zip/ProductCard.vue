<script setup>
defineProps({
  product: {
    type: Object,
    required: true,
  },
})

function formatPrice(price) {
  return '¥' + price.toFixed(2)
}
</script>

<template>
  <RouterLink :to="`/product/${product.id}`" class="product-card">
    <div class="card-image-wrap">
      <img :src="product.image" :alt="product.name" class="card-image" loading="lazy" />
      <!-- 标签 -->
      <div class="card-tags" v-if="product.tags?.length">
        <span
          v-for="tag in product.tags"
          :key="tag"
          class="card-tag"
          :class="{ 'tag-hot': tag === '热卖' || tag === '爆款', 'tag-new': tag === '新品' }"
        >
          {{ tag }}
        </span>
      </div>
    </div>

    <div class="card-info">
      <h3 class="card-name">{{ product.name }}</h3>
      <div class="card-meta">
        <span class="card-rating">⭐ {{ product.rating }}</span>
        <span class="card-sales">已售 {{ product.sales }}</span>
      </div>
      <div class="card-price">
        <span class="price-current">{{ formatPrice(product.price) }}</span>
        <span class="price-original" v-if="product.originalPrice">
          {{ formatPrice(product.originalPrice) }}
        </span>
      </div>
    </div>
  </RouterLink>
</template>

<style scoped>
.product-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  text-decoration: none;
  color: inherit;
  transition: all 0.3s ease;
  display: block;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.product-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.card-image-wrap {
  position: relative;
  width: 100%;
  padding-top: 100%;
  overflow: hidden;
  background: #f5f5f5;
}

.card-image {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.product-card:hover .card-image {
  transform: scale(1.05);
}

.card-tags {
  position: absolute;
  top: 8px;
  left: 8px;
  display: flex;
  gap: 4px;
  flex-wrap: wrap;
}

.card-tag {
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  color: #fff;
  background: #999;
}

.tag-hot {
  background: #ff4d4f;
}

.tag-new {
  background: #52c41a;
}

.card-info {
  padding: 14px;
}

.card-name {
  font-size: 15px;
  font-weight: 500;
  color: #333;
  margin: 0 0 8px;
  line-height: 1.4;
  /* 两行省略 */
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.card-meta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
  font-size: 13px;
  color: #999;
}

.card-rating {
  color: #f5a623;
}

.card-price {
  display: flex;
  align-items: baseline;
  gap: 8px;
}

.price-current {
  font-size: 20px;
  font-weight: 700;
  color: #ff4d4f;
}

.price-original {
  font-size: 13px;
  color: #bbb;
  text-decoration: line-through;
}
</style>
