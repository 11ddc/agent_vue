import axios from 'axios'

// ==================== Mock 数据 ====================

// 模拟商品数据
export const mockProducts = [
  {
    id: 1,
    name: '经典款纯棉T恤',
    category: 'clothing',
    price: 129.00,
    originalPrice: 199.00,
    image: 'https://picsum.photos/seed/tshirt/400/400',
    images: [
      'https://picsum.photos/seed/tshirt1/400/400',
      'https://picsum.photos/seed/tshirt2/400/400',
    ],
    description: '100% 纯棉面料，舒适透气，简约百搭的经典款T恤。适合日常休闲穿着，多色可选。',
    sales: 2356,
    rating: 4.8,
    reviews: 128,
    tags: ['新品', '热卖'],
    stock: 100,
  },
  {
    id: 2,
    name: '轻薄羽绒服',
    category: 'clothing',
    price: 599.00,
    originalPrice: 899.00,
    image: 'https://picsum.photos/seed/jacket/400/400',
    images: [
      'https://picsum.photos/seed/jacket1/400/400',
      'https://picsum.photos/seed/jacket2/400/400',
    ],
    description: '90%白鸭绒填充，轻薄保暖，可收纳设计。冬季出行必备，防风防泼水面料。',
    sales: 1523,
    rating: 4.6,
    reviews: 89,
    tags: ['冬季', '热卖'],
    stock: 50,
  },
  {
    id: 3,
    name: '复古运动鞋',
    category: 'shoes',
    price: 349.00,
    originalPrice: 499.00,
    image: 'https://picsum.photos/seed/sneakers/400/400',
    images: [
      'https://picsum.photos/seed/sneakers1/400/400',
      'https://picsum.photos/seed/sneakers2/400/400',
    ],
    description: '复古风格设计，EVA缓震中底，橡胶外底防滑耐磨。兼顾时尚与舒适。',
    sales: 3201,
    rating: 4.7,
    reviews: 205,
    tags: ['热卖', '潮流'],
    stock: 80,
  },
  {
    id: 4,
    name: '简约双肩背包',
    category: 'bags',
    price: 189.00,
    originalPrice: 259.00,
    image: 'https://picsum.photos/seed/backpack/400/400',
    images: [
      'https://picsum.photos/seed/backpack1/400/400',
      'https://picsum.photos/seed/backpack2/400/400',
    ],
    description: '大容量设计，防泼水尼龙面料，加厚电脑隔层。通勤、旅行两用。',
    sales: 1890,
    rating: 4.5,
    reviews: 156,
    tags: ['通勤', '实用'],
    stock: 120,
  },
  {
    id: 5,
    name: '无线降噪耳机',
    category: 'electronics',
    price: 799.00,
    originalPrice: 999.00,
    image: 'https://picsum.photos/seed/headphone/400/400',
    images: [
      'https://picsum.photos/seed/headphone1/400/400',
      'https://picsum.photos/seed/headphone2/400/400',
    ],
    description: '自适应主动降噪，40小时超长续航，Hi-Res音质认证。沉浸音乐体验。',
    sales: 4102,
    rating: 4.9,
    reviews: 312,
    tags: ['数码', '爆款'],
    stock: 200,
  },
  {
    id: 6,
    name: '智能手表 Pro',
    category: 'electronics',
    price: 1299.00,
    originalPrice: 1599.00,
    image: 'https://picsum.photos/seed/watch/400/400',
    images: [
      'https://picsum.photos/seed/watch1/400/400',
      'https://picsum.photos/seed/watch2/400/400',
    ],
    description: '1.5英寸AMOLED屏幕，心率血氧监测，GPS轨迹记录，100+运动模式。',
    sales: 2876,
    rating: 4.8,
    reviews: 198,
    tags: ['数码', '新品'],
    stock: 65,
  },
  {
    id: 7,
    name: '天然护肤精华液',
    category: 'beauty',
    price: 259.00,
    originalPrice: 359.00,
    image: 'https://picsum.photos/seed/serum/400/400',
    images: [
      'https://picsum.photos/seed/serum1/400/400',
      'https://picsum.photos/seed/serum2/400/400',
    ],
    description: '含玻尿酸+烟酰胺，深层补水保湿，改善肌肤暗沉。质地轻薄易吸收。',
    sales: 5678,
    rating: 4.7,
    reviews: 423,
    tags: ['美妆', '爆款'],
    stock: 300,
  },
  {
    id: 8,
    name: '北欧风台灯',
    category: 'home',
    price: 169.00,
    originalPrice: 229.00,
    image: 'https://picsum.photos/seed/lamp/400/400',
    images: [
      'https://picsum.photos/seed/lamp1/400/400',
      'https://picsum.photos/seed/lamp2/400/400',
    ],
    description: '简约北欧设计，三档色温可调，无频闪护眼。书桌、床头两相宜。',
    sales: 1345,
    rating: 4.4,
    reviews: 87,
    tags: ['家居', '新品'],
    stock: 90,
  },
]

// 商品分类
export const categories = [
  { key: 'all', name: '全部' },
  { key: 'clothing', name: '服饰' },
  { key: 'shoes', name: '鞋靴' },
  { key: 'bags', name: '箱包' },
  { key: 'electronics', name: '数码' },
  { key: 'beauty', name: '美妆' },
  { key: 'home', name: '家居' },
]

// 模拟用户数据
const mockUsers = [
  {
    id: 1,
    username: 'admin',
    email: 'admin@shop.com',
    password: '123456',
    avatar: 'https://picsum.photos/seed/avatar1/100/100',
  },
  {
    id: 2,
    username: 'test',
    email: 'test@shop.com',
    password: '123456',
    avatar: 'https://picsum.photos/seed/avatar2/100/100',
  },
]

// 客服预设回复
const chatResponses = [
  {
    keywords: ['你好', '嗨', 'hi', 'hello', '在吗'],
    reply: '您好！欢迎来到优选商城，我是客服小优，很高兴为您服务！请问有什么可以帮您的吗？',
  },
  {
    keywords: ['退货', '退款', '退换'],
    reply: '我们支持7天无理由退货，15天质量问题换货。请在我的订单中找到对应商品申请售后即可。如果订单已超过时效，请提供订单号，我帮您联系专员处理。',
  },
  {
    keywords: ['发货', '物流', '快递', '多久'],
    reply: '一般情况下，下单后48小时内安排发货。您可以在"我的订单"中查看实时物流信息。如遇促销高峰期，发货可能稍有延迟，敬请谅解~',
  },
  {
    keywords: ['优惠', '折扣', '优惠券', '活动'],
    reply: '目前我们有满200减30、满500减80的活动哦！新用户注册即送50元优惠券。还有每周三会员日，全场9折优惠，记得关注哦~',
  },
  {
    keywords: ['支付', '付款'],
    reply: '我们支持微信支付、支付宝、银行卡等多种支付方式。支付过程中遇到问题，请检查网络后重试，或更换支付方式。如有扣款未到账的情况，系统会在24小时内自动退款。',
  },
  {
    keywords: ['尺码', '大小', '颜色'],
    reply: '商品详情页有详细的尺码对照表和颜色展示哦。如果还有疑问，可以告诉我您的身高体重，我帮您推荐合适的尺码~',
  },
  {
    keywords: ['客服', '人工', '电话'],
    reply: '我是您的专属客服小优！在线时间为每天9:00-22:00。如需电话沟通，请拨打 400-888-6666。',
  },
]

// ==================== Mock API 拦截 ====================

// 创建 axios 实例
const api = axios.create({
  baseURL: '/api',
  timeout: 5000,
})

// 请求拦截器 - 模拟后端响应
api.interceptors.request.use((config) => {
  // 阻止请求发出，返回模拟数据
  return Promise.reject({ config, mock: true })
})

// 响应拦截器 - 处理模拟数据
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.mock) {
      const { url, method, data } = error.config
      let mockData = null

      try {
        const parsedData = data ? JSON.parse(data) : {}

        // ===== 商品相关 =====
        if (url === '/products' && method === 'get') {
          mockData = { code: 200, data: mockProducts, message: 'success' }
        } else if (url?.match(/\/products\/\d+/) && method === 'get') {
          const id = Number(url.split('/').pop())
          const product = mockProducts.find((p) => p.id === id)
          mockData = product
            ? { code: 200, data: product, message: 'success' }
            : { code: 404, data: null, message: '商品不存在' }
        } else if (url === '/categories' && method === 'get') {
          mockData = { code: 200, data: categories, message: 'success' }

          // ===== 登录 =====
        } else if (url === '/auth/login' && method === 'post') {
          const { username, password } = parsedData
          const user = mockUsers.find(
            (u) =>
              (u.username === username || u.email === username) &&
              u.password === password,
          )
          if (user) {
            const token = 'mock_token_' + user.id + '_' + Date.now()
            mockData = {
              code: 200,
              data: {
                token,
                user: { id: user.id, username: user.username, email: user.email, avatar: user.avatar },
              },
              message: '登录成功',
            }
          } else {
            mockData = { code: 401, data: null, message: '用户名或密码错误' }
          }

          // ===== 注册 =====
        } else if (url === '/auth/register' && method === 'post') {
          const { username, email, password } = parsedData
          const exists = mockUsers.find(
            (u) => u.username === username || u.email === email,
          )
          if (exists) {
            mockData = { code: 409, data: null, message: '用户名或邮箱已存在' }
          } else if (!username || !password) {
            mockData = { code: 400, data: null, message: '用户名和密码不能为空' }
          } else {
            const newUser = {
              id: mockUsers.length + 1,
              username,
              email: email || '',
              password,
              avatar: `https://picsum.photos/seed/avatar${mockUsers.length + 1}/100/100`,
            }
            mockUsers.push(newUser)
            const token = 'mock_token_' + newUser.id + '_' + Date.now()
            mockData = {
              code: 200,
              data: {
                token,
                user: { id: newUser.id, username: newUser.username, email: newUser.email, avatar: newUser.avatar },
              },
              message: '注册成功',
            }
          }

          // ===== 聊天 =====
        } else if (url === '/chat/send' && method === 'post') {
          const { message } = parsedData
          // 关键词匹配
          let reply = null
          for (const item of chatResponses) {
            if (item.keywords.some((kw) => message.includes(kw))) {
              reply = item.reply
              break
            }
          }
          if (!reply) {
            reply =
              '感谢您的咨询！您的问题我已经记录下来了，我会尽快给您答复。如有紧急问题，可以拨打客服热线：400-888-6666。'
          }
          mockData = {
            code: 200,
            data: {
              id: Date.now(),
              content: reply,
              sender: 'agent',
              timestamp: new Date().toISOString(),
            },
            message: 'success',
          }

          // ===== 默认 =====
        } else {
          mockData = { code: 404, data: null, message: '接口不存在' }
        }
      } catch (e) {
        mockData = { code: 500, data: null, message: '服务器内部错误' }
      }

      // 模拟网络延迟
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({ data: mockData })
        }, 300 + Math.random() * 500)
      })
    }
    return Promise.reject(error)
  },
)

export default api
