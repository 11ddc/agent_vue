<script setup>
import { ref } from 'vue'
import { useAuthStore } from '@/stores/auth.js'

const auth = useAuthStore()

const form = ref({
  username: '',
  password: '',
})
const error = ref('')
const loading = ref(false)

async function handleSubmit() {
  error.value = ''
  if (!form.value.username.trim() || !form.value.password.trim()) {
    error.value = '请输入用户名和密码'
    return
  }
  loading.value = true
  const result = await auth.login(form.value.username, form.value.password)
  loading.value = false
  if (result.success) {
    auth.closeModals()
    form.value = { username: '', password: '' }
  } else {
    error.value = result.message
  }
}

function handleOverlayClick(e) {
  if (e.target === e.currentTarget) {
    auth.closeModals()
  }
}
</script>

<template>
  <Teleport to="body">
    <div v-if="auth.showLoginModal" class="modal-overlay" @click="handleOverlayClick">
    <div class="modal-card">
      <button class="modal-close" @click="auth.closeModals()">✕</button>

      <div class="modal-header">
        <h2>欢迎登录</h2>
        <p>登录您的优选商城账号</p>
      </div>

      <form class="modal-form" @submit.prevent="handleSubmit">
        <div class="form-group">
          <label>用户名 / 邮箱</label>
          <input
            v-model="form.username"
            type="text"
            placeholder="请输入用户名或邮箱"
            :disabled="loading"
          />
        </div>

        <div class="form-group">
          <label>密码</label>
          <input
            v-model="form.password"
            type="password"
            placeholder="请输入密码"
            :disabled="loading"
          />
        </div>

        <p v-if="error" class="error-msg">{{ error }}</p>

        <button type="submit" class="btn-submit" :disabled="loading">
          {{ loading ? '登录中...' : '登录' }}
        </button>
      </form>

      <div class="modal-footer">
        <span>还没有账号？</span>
        <a href="#" @click.prevent="auth.switchToRegister()">立即注册</a>
      </div>

      <div class="test-hint">
        <p>测试账号：admin / 123456</p>
      </div>
    </div>
  </div>
  </Teleport>
</template>

<style scoped>
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
  animation: fadeIn 0.2s ease;
}

.modal-card {
  position: relative;
  width: 400px;
  max-width: 90vw;
  background: #fff;
  border-radius: 16px;
  padding: 40px 32px 32px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
  animation: slideUp 0.3s ease;
}

.modal-close {
  position: absolute;
  top: 16px;
  right: 16px;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: none;
  background: #f5f5f5;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}
.modal-close:hover {
  background: #e0e0e0;
  color: #333;
}

.modal-header {
  text-align: center;
  margin-bottom: 28px;
}
.modal-header h2 {
  font-size: 24px;
  color: #222;
  margin: 0 0 8px;
}
.modal-header p {
  font-size: 14px;
  color: #999;
  margin: 0;
}

.form-group {
  margin-bottom: 18px;
}
.form-group label {
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 6px;
}
.form-group input {
  width: 100%;
  padding: 10px 14px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s;
  box-sizing: border-box;
}
.form-group input:focus {
  border-color: #e74c3c;
}
.form-group input:disabled {
  background: #f9f9f9;
}

.error-msg {
  color: #e74c3c;
  font-size: 13px;
  margin: -8px 0 12px;
}

.btn-submit {
  width: 100%;
  padding: 12px;
  background: #e74c3c;
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
  margin-top: 4px;
}
.btn-submit:hover:not(:disabled) {
  background: #c0392b;
}
.btn-submit:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.modal-footer {
  margin-top: 20px;
  text-align: center;
  font-size: 14px;
  color: #999;
}
.modal-footer a {
  color: #e74c3c;
  text-decoration: none;
  font-weight: 500;
  margin-left: 4px;
}
.modal-footer a:hover {
  text-decoration: underline;
}

.test-hint {
  margin-top: 16px;
  padding: 10px;
  background: #fffbf0;
  border-radius: 8px;
  text-align: center;
}
.test-hint p {
  font-size: 12px;
  color: #b8860b;
  margin: 0;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes slideUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
