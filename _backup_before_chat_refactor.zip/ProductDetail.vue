<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import api from '@/api/mock.js'

const route = useRoute()
const product = ref(null)
const loading = ref(true)
const selectedImage = ref('')

async function fetchProduct() {
  loading.value = true
  try {
    const res = await api.get(`/products/${route.params.id}`)
    if (res.data.code === 200) {
      product.value = res.data.data
      selectedImage.value = res.data.data.image
    } else {
      product.value = null
    }
  } catch (err) {
    product.value = null
  } finally {
    loading.value = false
  }
}

function formatPrice(price) {
  return '¥' + price.toFixed(2)
}

onMounted(() => {
  fetchProduct()
})
</script>

<template>
  <div class="detail-page">
    <!-- 加载中 -->
    <div v-if="loading" class="loading-wrap">
      <div class="spinner"></div>
      <p>加载中...</p>
    </div>

    <!-- 商品不存在 -->
    <div v-else-if="!product" class="not-found">
      <p>😕 商品不存在</p>
      <RouterLink to="/" class="back-link">返回首页</RouterLink>
    </div>

    <!-- 商品详情 -->
    <template v-else>
      <!-- 面包屑 -->
      <div class="breadcrumb">
        <RouterLink to="/">首页</RouterLink>
        <span> / </span>
        <span>{{ product.name }}</span>
      </div>

      <div class="detail-main">
        <!-- 左侧图片 -->
        <div class="detail-gallery">
          <div class="main-image-wrap">
            <img :src="selectedImage" :alt="product.name" class="main-image" />
          </div>
          <div class="thumb-list">
            <img
              v-for="(img, i) in product.images"
              :key="i"
              :src="img"
              :class="{ active: selectedImage === img }"
              @click="selectedImage = img"
              class="thumb"
            />
          </div>
        </div>

        <!-- 右侧信息 -->
        <div class="detail-info">
          <h1 class="product-name">{{ product.name }}</h1>
          <p class="product-desc">{{ product.description }}</p>

          <div class="price-block">
            <span class="price-current">{{ formatPrice(product.price) }}</span>
            <span v-if="product.originalPrice" class="price-original">
              {{ formatPrice(product.originalPrice) }}
            </span>
            <span v-if="product.originalPrice" class="price-discount">
              省{{ formatPrice(product.originalPrice - product.price) }}
            </span>
          </div>

          <div class="meta-block">
            <span>⭐ {{ product.rating }} ({{ product.reviews }} 评价)</span>
            <span>📦 已售 {{ product.sales }}</span>
            <span>📦 库存 {{ product.stock }} 件</span>
          </div>

          <div class="tags-block" v-if="product.tags?.length">
            <span v-for="tag in product.tags" :key="tag" class="tag">{{ tag }}</span>
          </div>

          <div class="action-block">
            <button class="btn-buy">立即购买</button>
            <button class="btn-cart">加入购物车</button>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.detail-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px 20px;
  min-height: 80vh;
}

/* 面包屑 */
.breadcrumb {
  font-size: 14px;
  color: #999;
  margin-bottom: 24px;
}

.breadcrumb a {
  color: #ff6b35;
  text-decoration: none;
}

.breadcrumb a:hover {
  text-decoration: underline;
}

/* 加载 & 空 */
.loading-wrap,
.not-found {
  text-align: center;
  padding: 80px 0;
  color: #999;
}

.spinner {
  width: 40px;
  height: 40px;
  border: 3px solid #f0f0f0;
  border-top-color: #ff6b35;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin: 0 auto 12px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.back-link {
  display: inline-block;
  margin-top: 12px;
  color: #ff6b35;
  text-decoration: none;
}

/* 主体 */
.detail-main {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  background: #fff;
  border-radius: 16px;
  padding: 32px;
}

@media (max-width: 768px) {
  .detail-main {
    grid-template-columns: 1fr;
    gap: 24px;
    padding: 16px;
  }
}

/* 图片 */
.detail-gallery {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.main-image-wrap {
  border-radius: 12px;
  overflow: hidden;
  background: #f5f5f5;
}

.main-image {
  width: 100%;
  aspect-ratio: 1;
  object-fit: cover;
}

.thumb-list {
  display: flex;
  gap: 8px;
}

.thumb {
  width: 64px;
  height: 64px;
  border-radius: 8px;
  object-fit: cover;
  cursor: pointer;
  border: 2px solid transparent;
  transition: border-color 0.2s;
}

.thumb:hover {
  border-color: #ff6b35;
}

.thumb.active {
  border-color: #ff6b35;
}

/* 信息 */
.detail-info {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.product-name {
  font-size: 24px;
  font-weight: 700;
  color: #222;
  margin: 0;
}

.product-desc {
  font-size: 15px;
  color: #666;
  line-height: 1.7;
  margin: 0;
}

.price-block {
  display: flex;
  align-items: baseline;
  gap: 12px;
  padding: 16px 0;
  border-top: 1px solid #f0f0f0;
  border-bottom: 1px solid #f0f0f0;
}

.price-current {
  font-size: 32px;
  font-weight: 700;
  color: #ff4d4f;
}

.price-original {
  font-size: 16px;
  color: #bbb;
  text-decoration: line-through;
}

.price-discount {
  font-size: 12px;
  background: #fff0f0;
  color: #ff4d4f;
  padding: 2px 8px;
  border-radius: 4px;
}

.meta-block {
  display: flex;
  gap: 20px;
  font-size: 14px;
  color: #888;
}

.tags-block {
  display: flex;
  gap: 8px;
}

.tag {
  padding: 4px 12px;
  background: #fff5f0;
  color: #ff6b35;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}

.action-block {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.btn-buy,
.btn-cart {
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-buy {
  background: #ff6b35;
  color: #fff;
}

.btn-buy:hover {
  background: #e55a2b;
}

.btn-cart {
  background: #fff;
  color: #ff6b35;
  border: 2px solid #ff6b35;
}

.btn-cart:hover {
  background: #fff5f0;
}
</style>
